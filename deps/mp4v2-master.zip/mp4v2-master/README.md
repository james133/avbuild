# mp4v2

This is a fork of mp4v2 from https://code.google.com/archive/p/mp4v2/.

TechSmith has modified this code for its own purposes and openly publishes those changes here in compliance with the Mozilla Public License.

-------
<pre>
All docs are located in doc/ subdirectory. Useful starting points:

Release Notes           -- doc/ReleaseNotes.txt
Building the Source     -- doc/BuildSource.txt
Building the Repository -- doc/BuildRepository.txt

See the COPYING file for license rights and limitations
</pre>